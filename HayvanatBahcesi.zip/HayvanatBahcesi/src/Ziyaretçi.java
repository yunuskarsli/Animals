import java.util.Scanner;

public class Ziyaretçi extends Users{
    public static void yemVer(int kg){
        Scanner scanner=new Scanner(System.in);
        scanner.nextInt();
        System.out.println(kg +"kg yem ayarlandı peki hangi hayvana verelim");
    }
}
